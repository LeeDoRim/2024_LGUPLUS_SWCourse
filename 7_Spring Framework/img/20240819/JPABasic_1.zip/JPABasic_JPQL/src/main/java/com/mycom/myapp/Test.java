package com.mycom.myapp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.jpa.HibernatePersistenceProvider;

import com.mycom.myapp.config.MyPersistenceUnitInfo;
import com.mycom.myapp.entity.Book;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Query;
import jakarta.persistence.TypedQuery;

// JPQL
// select no commit (commit 하지 않아도 된다.)
// insert, update, delete commit 필요하다.
// JPQL은 insert가 없다. update, delete는 있다.  // (여기서 다루지 않는다.)
public class Test {

	public static void main(String[] args) {

		Map<String, String> props = new HashMap<>();
		props.put("hibernate.show_sql", "true");	// sql 명령문을 확인할 수 있다.
		props.put("hibernate.hbm2ddl.auto", "update");	// 속성에 create, update 등이 올 수 있다.
		
		EntityManagerFactory emf = new HibernatePersistenceProvider().createContainerEntityManagerFactory(new MyPersistenceUnitInfo(), props);
		EntityManager em = emf.createEntityManager();
		
		try {
			// #1 normal Query (단순 Query)
//			{
//				String jpql = "select b from Book b"; // table이 아닌 entity를 대상 // 따라서 book이 아닌 Book을 사용해야 한다.
//				Query query = em.createQuery(jpql);
//				List<Book> bookList = query.getResultList();
//
//				for (Book book : bookList) {
//					System.out.println(book);
//				}
//			}
			
			// #2 Typed Query (타입을 지정한 Query) (권장)			
//			{
//				String jpql = "select b from Book b"; // table이 아닌 entity를 대상 // 따라서 book이 아닌 Book을 사용해야 한다.
//				TypedQuery<Book> query = em.createQuery(jpql, Book.class);
//				List<Book> bookList = query.getResultList();
//				
//				for (Book book : bookList) {
//					System.out.println(book);
//				}
//			}
			
			// #3 Parameter : positional Parameter 		
//			{
//				String jpql = "select b from Book b where price > ?1"; // ? + 순서번호
//				TypedQuery<Book> query = em.createQuery(jpql, Book.class);
//				query.setParameter(1, 15000);
//				List<Book> bookList = query.getResultList();
//				
//				for (Book book : bookList) {
//					System.out.println(book);
//				}
//			}
			
			// #4 Parameter : named Parameter 		
//			{
//				String jpql = "select b from Book b where price > :price"; // ? + 순서번호
//				TypedQuery<Book> query = em.createQuery(jpql, Book.class);
//				query.setParameter("price", 15000);
//				List<Book> bookList = query.getResultList();
//				
//				for (Book book : bookList) {
//					System.out.println(book);
//				}
//			}
			
			// #5 Parameter : positional Parameter, named Parameter together (별로 좋은 방법은 아니다.)
//			{
//				String jpql = "select b from Book b where b.price > :price and b.price < ?1"; // ? + 순서번호
//				TypedQuery<Book> query = em.createQuery(jpql, Book.class);
//				query.setParameter("price", 15000);
//				query.setParameter(1, 30000);
//				List<Book> bookList = query.getResultList();
//				
//				for (Book book : bookList) {
//					System.out.println(book);
//				}
//			}
			
			// #6 like
			// bookname
			{
				String searchWord = "축구";
				String searchPattern = "%" + searchWord + "%";
				String jpql = "select b from Book b where b.bookname like :searchPattern ";
				TypedQuery<Book> query = em.createQuery(jpql, Book.class);
				query.setParameter("searchPattern", searchPattern);
				List<Book> bookList = query.getResultList();
				
				for (Book book : bookList) {
					System.out.println(book);
				}
			}
		
			
		} finally {
			em.close();
		}
		
		
	}

}
