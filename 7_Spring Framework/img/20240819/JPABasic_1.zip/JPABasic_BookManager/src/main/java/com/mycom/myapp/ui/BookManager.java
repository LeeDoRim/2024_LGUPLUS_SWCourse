package com.mycom.myapp.ui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.TextField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame; // windows application
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;


import com.mycom.myapp.dao.BookDao;
import com.mycom.myapp.dto.BookDto;


public class BookManager extends JFrame{ 
	
	// tableModel이 값을 가지고 있고 table 형식을 가지고 있어서 둘이 연계하여 화면을 보여준다.
	private JTable table; // grid ui component
	private DefaultTableModel tableModel;	// grid 형태의 data롤 표현
	private JButton searchButton, addButton, editButton, listButton;	// 버튼 생성
	private JTextField searchWordField;	// 검색어 입력칸

	// bookDao
	private BookDao bookDao = new BookDao();
	
	public BookManager() {

		// 화면 UI와 관련된 설정
		setTitle("Book Manager");
		setSize(600, 400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // 종료 버튼을 누르면 종료
		setLocationRelativeTo(null);
		
		// table
		// int[][] ab = new int[]{1,2,3} 형식
		// DefaultTableModel(row에 넣을 값 객체, rowCount);
		tableModel = new DefaultTableModel(new Object[] {"Book ID", "Book Name", "Publisher", "Price"}, 0) {
			// 목록에서 수정할 수 없게 변경
			@Override
            public boolean isCellEditable(int row, int column) {
                return false; // All cells are not editable
            }
		};
		table = new JTable(tableModel);
		
		// DB로부터 현재 book 테이블에 있는 데이터를 가져와서 보여준다.
		listBook();
		
		// search
		Dimension TextFieldSize = new Dimension(400, 28);
		
		searchWordField = new JTextField();
		searchWordField.setPreferredSize(TextFieldSize);
		
		searchButton = new JButton("검색");
		
		JPanel searchPanel = new JPanel();
		searchPanel.add(new JLabel("제목 검색"));
		searchPanel.add(searchWordField);
		searchPanel.add(searchButton);
		
		// Button
		addButton = new JButton("등록");
		editButton = new JButton("수정 & 삭제");
		listButton = new JButton("목록");
		
		// bookManager의 BorderLayout SOUTH에 버튼을 2개 담을 수 없으므로 다른 패널에 버튼 2개를 담아서 붙인다.
		// button 2개를 담는 JPanel 객체를 만들고 그 객체를 BookManager에 담는다.
		JPanel buttonPanel = new JPanel(); // default layout : Flow Layout
		buttonPanel.add(addButton);
		buttonPanel.add(editButton);
		buttonPanel.add(listButton);
		
		// table을 BookManager에 붙인다.
		// BookManager의 layout에 따라 결정된다.
		// BookManager layout 종류 : Gridlayout, BorderLayout, CardLayout ...
		
		// BookManager의 layout 설정
		setLayout(new BorderLayout());
		// add(table, BorderLayout.CENTER);
		add(searchPanel, BorderLayout.NORTH);
		add(new JScrollPane(table), BorderLayout.CENTER); // table < scroll pane < jframe 형태로 table이 많아지면 스크롤이 생기도록 함.
		add(buttonPanel, BorderLayout.SOUTH);
		
		// button action event 처리
		// event 객체를 받아서 처리하는 로직을 가진 객체 <= ActionListener interface를 구현해야 한다.
		searchButton.addActionListener(e -> { 
			String searchWord = searchWordField.getText();
			if( !searchWord.isBlank() ) {
				listBook(searchWord);
			}
		}); 
		
		addButton.addActionListener(e -> { 
				// AddBookDialog를 띄운다.
			AddBookDialog addDialog = new AddBookDialog(this, this.tableModel);
			addDialog.setVisible(true);
		}); 
		
		editButton.addActionListener(e -> { 
			// table에 선택된 row가 있으면 AddBookDialog를 띄운다.
			// table에 선택된 row
			int selectedRow = table.getSelectedRow();
			if( selectedRow >= 0) {
				EditBookDialog editDialog = new EditBookDialog(this, this.tableModel, selectedRow);
				editDialog.setVisible(true);
			} else {
				JOptionPane.showMessageDialog(this, "도서를 선택하세요.");
			}
		}); 
		
		listButton.addActionListener(e -> listBook() );
		
		// 테이블에서 마우스 이벤트 처리 메소드 추가
		table.addMouseListener(new MouseAdapter() {
			// 마우스 더블 클릭이 되면 edit 팝업을 띄운다. 
			@Override
            public void mouseClicked(MouseEvent e) {
                // double click
                if (e.getClickCount() == 2) { // 클릭 2회 = 더블 클릭
                    int selectedRow = table.getSelectedRow();
                    if (selectedRow >= 0) {
                        EditBookDialog editDialog = new EditBookDialog(BookManager.this, tableModel, selectedRow);
                        editDialog.setVisible(true);
                    }
                }
            }
		});
	}
	
	private void clearTable() {
		tableModel.setRowCount(0);
	}
	
	private void listBook() {
		// 현재 tableModel을 정리하고 처리
		clearTable();
		
		List<BookDto> bookList = bookDao.listBook();
		
		for (BookDto book : bookList) {
			tableModel.addRow(new Object[] {book.getBookId(), book.getBookName(), book.getPublisher(), book.getPrice()});
		}
	}
	
	private void listBook(String searchWord) {
		// 현재 tableModel을 정리하고 처리
		clearTable();
		
		List<BookDto> bookList = bookDao.listSearchBook(searchWord);
		
		for (BookDto book : bookList) {
			tableModel.addRow(new Object[] {book.getBookId(), book.getBookName(), book.getPublisher(), book.getPrice()});
		}
	}
	
	BookDto detailBook(int bookId) {
		return bookDao.detailBook(bookId);
	}
	
	void insertBook(BookDto book) {
		bookDao.insertBook(book);
		listBook();
	}
	
	void updateBook(BookDto book) {
		bookDao.updatetBook(book);
		listBook();
	}
	
	void deleteBook(int bookId) {
		bookDao.deleteBook(bookId);
		listBook();
	}
	
	public static void main(String[] args) {
		// main() thread와 별개로 별도의 thread로 화면을 띄운다.
		// thread 처리를 간단히 해주는 utility method 제공한다.
		// invokeLater( thread 객체 <- runnable interface를 구현한 <- runnable interface가 functional interface
		// 결과적으로 invokeLater( lambda 식 표현 객체)
		SwingUtilities.invokeLater(() -> {
			new BookManager().setVisible(true);
//			BookManager bookManager = new BookManager();
//			bookManager.setVisible(true);
		});

	}

}
