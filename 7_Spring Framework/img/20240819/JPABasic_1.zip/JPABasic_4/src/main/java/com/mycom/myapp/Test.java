package com.mycom.myapp;

import java.util.HashMap;
import java.util.Map;

import org.hibernate.jpa.HibernatePersistenceProvider;

import com.mycom.myapp.config.MyPersistenceUnitInfo;
import com.mycom.myapp.entity.Employee;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;

//  org.hibernate.UnknownEntityTypeException: Unable to locate entity descriptor: com.mycom.myapp.entity.Employee
// 해결방법 : com.mycom.myapp.config.MyPersistenceUnitInfo.java의 getManagedClassNames 메소드에 해당 entity를 추가한다.

// EntityManagerFactory의 HashMap에 몇 가지 설정
public class Test {

	public static void main(String[] args) {

		Map<String, String> props = new HashMap<>();
		props.put("hibernate.show_sql", "true");	// sql 명령문을 확인할 수 있다.
		props.put("hibernate.hbm2ddl.auto", "update");	// 속성에 create, update 등이 올 수 있다.
		// hbm2ddl <= Hibernate Mapping to (2) DDL
		
		EntityManagerFactory emf = new HibernatePersistenceProvider().createContainerEntityManagerFactory(new MyPersistenceUnitInfo(), props);
		EntityManager em = emf.createEntityManager();
		
		try {
			em.getTransaction().begin();
			
			// sql 확인
//			{
//				Employee e1 = new Employee();
//				e1.setId(1);
//				e1.setName("홍길동");
//				e1.setAddress("서울 어디");
//				em.persist(e1);
//			}
			
//			{
//				Employee e1 = em.find(Employee.class, 1);
//				System.out.println(e1);
//			}
			
//			{
//				Employee e1 = new Employee();
//				e1.setId(1);
//				e1.setName("홍길동");
//				e1.setAddress("서울 어디");
//				em.persist(e1);
//				
//				System.out.println(e1);
//				
//				// delay
//				try {
//					Thread.sleep(10000);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//				
//			}

//			{
//				Employee e1 = em.find(Employee.class, 1);
//				e1.setAddress("제주 어디");
//				System.out.println(e1);
//				
//				// delay
//				try {
//					Thread.sleep(10000);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
			
			// create, update 설정으로 현재 employee table empty
			// employee table drop
//			{
//				Employee e1 = em.find(Employee.class, 1);
//				System.out.println(e1);
//				
//				e1 = new Employee();
//				e1.setId(1);
//				e1.setName("홍길동");
//				e1.setAddress("서울 어디");
//				em.persist(e1);
//				
//				e1 = em.find(Employee.class, 1); // select 수행 X
//				// find()는 persistence context에 있으면 거기서 찾는다. 없으면 DB에서 가져온다.
//				System.out.println(e1);
//			}
			
			// getReference()
			// 현재 DB 1 건 employee 데이터 존재
//			{
//				// find() 즉각 실행 된다.
//				// getReference() 사용될 때 실행 된다. (지연 로딩)
////				Employee e1 = em.find(Employee.class, 1); // 즉시
//				Employee e1 = em.getReference(Employee.class, 1); // find() X
////				e1.setName("이길동");
//				
//				// delay
//				try {
//					Thread.sleep(10000);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//				
//				System.out.println(e1);
//			}

			
			// remove
			// persistence context에서 제거
//			{
//				Employee e1 = em.find(Employee.class, 1); 
//				
//				em.remove(e1);
//				
//				// delay
//				try {
//					Thread.sleep(10000);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//				
//				System.out.println(e1);
//			}

			// refresh
			// 현재 context에 있는 데이터를 DB에 있는 데이터로 다시 덮어씌운다.
			{
				Employee e1 = em.find(Employee.class, 1); 

				// refresh 전, 주소 변경
				e1.setAddress("아까 거기");

				System.out.println(e1);
				
				// delay
				try {
					Thread.sleep(10000);
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				em.refresh(e1);
				
				// refresh 후
				System.out.println(e1);
			}
			
			
			em.getTransaction().commit(); // update 수행
		} finally {
			em.close();
		}
		
		
	}

}
