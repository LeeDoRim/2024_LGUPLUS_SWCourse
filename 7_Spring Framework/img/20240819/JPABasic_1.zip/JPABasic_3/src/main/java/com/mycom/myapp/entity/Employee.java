package com.mycom.myapp.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

// entity class 에 대응하는 table명이 다르거나, field에 대응하는 column명이 다르면 
// @Table, @Column을 이용해서 적용핧 수 있다.

@Entity
@Table(name = "employee") // 테이블명과 자바 Entity class 이름이 다를 경우 사용한다. 
public class Employee {
	
	@Id
	@Column(name="id")
	private int id;
	private String name;
	private String  address;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", address=" + address + "]";
	}
	
	
	

}
