package com.mycom.myapp;

import java.util.HashMap;

import org.hibernate.jpa.HibernatePersistenceProvider;

import com.mycom.myapp.config.MyPersistenceUnitInfo;
import com.mycom.myapp.entity.Employee;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;

//  org.hibernate.UnknownEntityTypeException: Unable to locate entity descriptor: com.mycom.myapp.entity.Employee
// 해결방법 : com.mycom.myapp.config.MyPersistenceUnitInfo.java의 getManagedClassNames 메소드에 해당 entity를 추가한다.
public class Test {

	public static void main(String[] args) {

		EntityManagerFactory emf = new HibernatePersistenceProvider().createContainerEntityManagerFactory(new MyPersistenceUnitInfo(), new HashMap<>());
		EntityManager em = emf.createEntityManager();
		
		try {
			em.getTransaction().begin();
			
			// persist() => Entity 객체가 persistence context 안으로 들어 온다.
			// find() => DB의 특정 row를 persistence context 안으로 들어 오게 한다. Entity 객체로 표현
//			{
//				Employee e1 = em.find(Employee.class, 1);
//				System.out.println(e1);
//			}
			
//			{
//				Employee e1 = em.find(Employee.class, 1);
//				e1.setAddress("부산 어디"); // 이 시점에 DB에 update 수행되지 않는다.
//				System.out.println(e1);
//			}
			
//			{
//				// new로 생성한 e1 객체는 영속성 컨텍스트에 있지 않으므로 출력 결과는 address가 '광주 어디'로 보이지만,
//				// employee 테이블의 id가 1인 데이터의 address는 변경되지 않는다.
//				Employee e1 = new Employee();
//				e1.setId(1);
//				e1.setAddress("광주 어디"); // 이 시점에 DB에 update 수행되지 않는다.
//				System.out.println(e1);
//			}
			
//			{
//				// update가 발생하지 않는다.
//				// 변경을 감지하고 있어서, 수정이 일어나지 않으면 update되지 않는다.
//				Employee e1 = em.find(Employee.class, 1);
//				e1.setAddress("광주 어디"); 
//				e1.setAddress("부산 어디");
//				System.out.println(e1);
//			}
			
//			{
//				Employee e1 = new Employee();
//				e1.setId(2);
//				e1.setAddress("강원 어디");
//				System.out.println(e1);
//				
//				// em.persist(e1);  // Duplicate entry '2' for key 'employee.PRIMARY'
//				em.merge(e1);  // DB에 해당 칼럼이 있으면 update 수행한다.
//			}
			
			{
				Employee e1 = new Employee();
				e1.setId(3);
				e1.setAddress("충청 어디");
				System.out.println(e1);
				
				// em.persist(e1);  // insert
				em.merge(e1);  // DB에 해당 칼럼이 없으면 insert를 수행한다.
			}
			
			
			em.getTransaction().commit(); // update 수행
		} finally {
			em.close();
		}
		
		
	}

}
