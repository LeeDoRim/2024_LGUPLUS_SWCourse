package servlet;

import java.io.IOException;
import java.util.List;

import dao.CustomerDao;
import dto.CustomerDto;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

// BookServlet 한 개에서 다양한 처리(crud)를 하기 위해 sub url
// /books/list : 목록
// /books/detail : 상세 ...
@WebServlet("/customers/*")
public class CustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 기능 구현은 이곳에만 한다.
		// http://localhost:8000/BookManager/books/list
		// /BookManager/books/list
		// /BookManager
//		System.out.println(request.getRequestURI());
//		System.out.println(request.getContextPath());
		
		String job = request.getRequestURI().substring(request.getContextPath().length());
		System.out.println(job);
		
		switch(job) {
		case "/customers/list" : list(request, response); break;
		case "/customers/detail" : detail(request, response); break;
		case "/customers/insert" : insert(request, response); break;
		case "/customers/update" : update(request, response); break;
		case "/customers/delete" : delete(request, response); break;
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// post로 요청이 오더라도 get에서 처리된다.
		doGet(request, response);
	}

	private void list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CustomerDao customerDao = new CustomerDao();
		List<CustomerDto> customerList = customerDao.listcustomer();
		request.setAttribute("customerList", customerList);
		request.getRequestDispatcher("/list.jsp").forward(request, response);
	}
	
	private void detail(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CustomerDao customerDao = new CustomerDao();
		int custId = Integer.parseInt(request.getParameter("custId"));
		CustomerDto customerDto = customerDao.detailcustomer(custId);
		request.setAttribute("customerDto", customerDto);
		request.getRequestDispatcher("/detailForm.jsp").forward(request, response);
	}
	
	private void insert(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CustomerDao customerDao = new CustomerDao();
		int custId = Integer.parseInt(request.getParameter("custId"));
		String name = request.getParameter("name"); // detailForm 태크의 name 속성
		String address = request.getParameter("address"); // detailForm 태크의 name 속성
		String phone = request.getParameter("phone");
		
		CustomerDto customerDto = new CustomerDto(custId, name, address, phone);
		int ret = customerDao.insertCustomer(customerDto);
		request.getRequestDispatcher("/insertResult.jsp").forward(request, response);
	}
	
	private void update(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CustomerDao customerDao = new CustomerDao();
		int custId = Integer.parseInt(request.getParameter("custId"));
		String name = request.getParameter("name"); // detailForm 태크의 name 속성
		String address = request.getParameter("address"); // detailForm 태크의 name 속성
		String phone = request.getParameter("phone");
		
		CustomerDto customerDto = new CustomerDto(custId, name, address, phone);
		int ret = customerDao.updateCustomer(customerDto);
		request.getRequestDispatcher("/updateResult.jsp").forward(request, response);
	}
	
	private void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CustomerDao customerDao = new CustomerDao();
		
		int custId = Integer.parseInt(request.getParameter("custId"));
		int ret = customerDao.deleteCustomer(custId);
		request.getRequestDispatcher("/deleteResult.jsp").forward(request, response);
	}
	
	
}
