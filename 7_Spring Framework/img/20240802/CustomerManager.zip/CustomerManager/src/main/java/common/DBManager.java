package common;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

// Tomcat이 관리하는 Connection Pool (DataSource)에서 connection 객체를 얻고 반납한다.
public class DBManager {
	
	public static Connection getConnection() {
		Connection con = null;
		try {
			
			// connection Pool 설정
			Context context = new InitialContext();
			DataSource ds = (DataSource) context.lookup("java:comp/env/jdbc/madangdb");
			con = ds.getConnection();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return con;
	}
	
	public static void releaseConnection(PreparedStatement pstmt, Connection con) {
		try {
			pstmt.close();
			con.close();  // connection Pool로 되돌아가는 코드로 되어 있다.
		} catch(SQLException e) {
			e.printStackTrace();
		} 
	}
	
	public static void releaseConnection(ResultSet rs, PreparedStatement pstmt, Connection con) {
		try {
			rs.close();
			pstmt.close();
			con.close();
		} catch(SQLException e) {
			e.printStackTrace();
		} 
	}

}
