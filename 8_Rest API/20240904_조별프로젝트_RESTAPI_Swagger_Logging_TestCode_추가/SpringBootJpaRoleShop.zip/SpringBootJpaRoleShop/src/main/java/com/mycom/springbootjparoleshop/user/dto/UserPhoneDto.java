package com.mycom.springbootjparoleshop.user.dto;

import lombok.Data;

@Data
public class UserPhoneDto {

	private Long id;
	private String phone;
	
}
