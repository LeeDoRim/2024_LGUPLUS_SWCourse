package com.mycom.springbootjparoleshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJpaRoleShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpaRoleShopApplication.class, args);
	}

}
