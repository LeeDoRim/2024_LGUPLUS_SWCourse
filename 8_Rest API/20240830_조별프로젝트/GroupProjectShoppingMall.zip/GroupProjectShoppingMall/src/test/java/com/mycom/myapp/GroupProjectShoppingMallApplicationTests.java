package com.mycom.myapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroupProjectShoppingMallApplicationTests {

	@Test
	void contextLoads() {
	}

}
