package com.mycom.myapp.user.dto;

import lombok.Data;

@Data
public class UserPhoneDto {

	private Long id;
	private String phone;
	
}
