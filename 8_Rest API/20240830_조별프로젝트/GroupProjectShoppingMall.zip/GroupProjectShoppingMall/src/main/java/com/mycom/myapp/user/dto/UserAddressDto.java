package com.mycom.myapp.user.dto;

import lombok.Data;

@Data
public class UserAddressDto {

	private Long id;
	private String addr1;
	private String addr2;
	private String zipCode;
	
}
