package com.mycom.myapp.product.service;

import com.mycom.myapp.product.dto.ProductResultDto;

public interface ProductService {
	
	// 회원 상품 조회
	ProductResultDto listAllProduct();

}
