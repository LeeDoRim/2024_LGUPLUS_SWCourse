package com.springboot.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityBook13StudyApplicationTests {

	@Test
	void contextLoads() {
	}

}
