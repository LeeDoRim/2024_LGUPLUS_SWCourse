package coupang.dto;

public class MenuDetail {

}
